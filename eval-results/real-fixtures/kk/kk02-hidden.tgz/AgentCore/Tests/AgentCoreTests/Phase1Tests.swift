import Foundation
import Testing
@testable import AgentCore
@testable import EvalKit

// Phase 1 of GAP_ANALYSIS.md (agentic core): B4 grep on ripgrep, …

private func grep(_ args: [String: JSONValue], in ws: Workspace, rg: URL?, maxBytes: Int = 16_000) async -> ToolOutput {
    let tool = GrepTool(rg: rg)
    return await AgentLoop.execute(ToolCall(id: "t", name: tool.name,
                                            arguments: String(decoding: try! JSONEncoder().encode(JSONValue.object(args)), as: UTF8.self)),
                                   tools: [tool.name: tool], config: AgentConfig(tools: [tool], maxToolOutputBytes: maxBytes),
                                   workspace: ws)
}

private func put(_ text: String, _ path: String, in ws: Workspace) throws {
    let url = ws.root.appending(path: path)
    try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
    try Data(text.utf8).write(to: url)
}

/// Both engines: the bundled ripgrep and the built-in search. Each test runs on both and must give the same text.
private let engines: [String] = ["rg", "builtin"]
private func engine(_ name: String) -> URL? {
    name == "rg" ? Ripgrep.locate([:]) : nil
}

@Suite struct GrepB4Tests {
    @Test func theBundledRipgrepIsFound() throws {
        let rg = try #require(Ripgrep.locate([:]))
        #expect(rg.path.hasSuffix("Bin/rg"))
        #expect(Ripgrep.locate(["KURTKODE_RG": "none"]) == nil)
        #expect(Ripgrep.locate(["KURTKODE_RG": "/no/such/rg"]) == nil)
        #expect(Ripgrep.locate(["KURTKODE_RG": rg.path]) == rg)
    }

    @Test(arguments: engines) func countModeGivesPerFileCountsAndATotal(_ e: String) async throws {
        let ws = try makeProject(git: true)
        try put((1...40).map { $0 % 4 == 0 ? "warning: unused \($0)" : "ok \($0)" }.joined(separator: "\n") + "\n", "build.log", in: ws)
        try put("warning: one\nwarning: two\n", "src/more.log", in: ws)
        let out = await grep(["pattern": "^warning:", "output_mode": "count"], in: ws, rg: engine(e))
        #expect(out.text == "build.log: 10\nsrc/more.log: 2\nTotal: 12 matching lines in 2 files.", "\(e): \(out.text)")
    }

    @Test(arguments: engines) func contextLinesAndGroupSeparators(_ e: String) async throws {
        let ws = try makeProject()
        try put((1...20).map { $0 == 5 || $0 == 15 ? "HIT \($0)" : "line \($0)" }.joined(separator: "\n") + "\n", "a.txt", in: ws)
        let out = await grep(["pattern": "HIT", "context": 1], in: ws, rg: engine(e))
        #expect(out.text == "a.txt-4- line 4\na.txt:5: HIT 5\na.txt-6- line 6\n--\na.txt-14- line 14\na.txt:15: HIT 15\na.txt-16- line 16",
                "\(e): \(out.text)")
        let after = await grep(["pattern": "HIT", "-A": 2, "glob": "a.txt"], in: ws, rg: engine(e))
        #expect(after.text.hasPrefix("a.txt:5: HIT 5\na.txt-6- line 6\na.txt-7- line 7\n--\na.txt:15:"), "\(e): \(after.text)")
        // Overlapping context merges into one group.
        let near = await grep(["pattern": "HIT", "context": 5], in: ws, rg: engine(e))
        #expect(!near.text.contains("--"), "\(e): \(near.text)")
    }

    @Test(arguments: engines) func filesModeAndTypeFilter(_ e: String) async throws {
        let ws = try makeProject(git: true)
        try put("def greet(): pass\n", "tools/greet.py", in: ws)
        let files = await grep(["pattern": "greet", "output_mode": "files_with_matches"], in: ws, rg: engine(e))
        #expect(files.text == "docs/guide.md\nsrc/main.swift\ntools/greet.py", "\(e): \(files.text)")
        let py = await grep(["pattern": "greet", "type": "python"], in: ws, rg: engine(e))
        #expect(py.text == "tools/greet.py:1: def greet(): pass", "\(e): \(py.text)")
        // The old parameter still works.
        let old = await grep(["pattern": "greet", "files_only": true], in: ws, rg: engine(e))
        #expect(old.text == files.text)
        // An unknown type is taken as an extension, and the result says so.
        try put("greet\n", "logs/app.log", in: ws)
        let log = await grep(["pattern": "greet", "type": "log"], in: ws, rg: engine(e))
        #expect(log.text == "logs/app.log:1: greet", "\(e): \(log.text)")
        let ext = await grep(["pattern": "greet", "type": "cobol"], in: ws, rg: engine(e))
        #expect(ext.text.hasPrefix("No matches") && ext.text.contains("isn't a known type; searched *.cobol files"))
        let bad = await grep(["pattern": "greet", "type": "*.{a,b}"], in: ws, rg: engine(e))
        #expect(bad.isError && bad.text.contains("unknown file type") && bad.text.contains("swift"))
    }

    @Test(arguments: engines) func paging(_ e: String) async throws {
        let ws = try makeProject()
        try put((1...30).map { "item \($0)" }.joined(separator: "\n") + "\n", "list.txt", in: ws)
        let first = await grep(["pattern": "item", "head_limit": 10], in: ws, rg: engine(e))
        #expect(first.truncated)
        #expect(first.text.hasSuffix("list.txt:10: item 10\n[Showing lines 1–10 of 30 (30 matching lines in 1 file). Use offset=10 for more, or narrow with glob, type or path.]"),
                "\(e): \(first.text)")
        let last = await grep(["pattern": "item", "head_limit": 10, "offset": 25], in: ws, rg: engine(e))
        #expect(last.text.hasPrefix("list.txt:26: item 26"))
        #expect(last.text.hasSuffix("[Showing lines 26–30 of 30 (30 matching lines in 1 file).]"), "\(e): \(last.text)")
        #expect(!last.truncated)
        let past = await grep(["pattern": "item", "offset": 99], in: ws, rg: engine(e))
        #expect(past.text.contains("past the end: there are 30 results"))
    }

    @Test(arguments: engines) func multilineMatchesSpanLines(_ e: String) async throws {
        let ws = try makeProject()
        try put("struct A {\n    let x: Int\n}\nstruct B {}\n", "m.swift", in: ws)
        let out = await grep(["pattern": "struct A \\{.*?\\}", "multiline": true], in: ws, rg: engine(e))
        #expect(out.text == "m.swift:1: struct A {\nm.swift:2:     let x: Int\nm.swift:3: }", "\(e): \(out.text)")
        let count = await grep(["pattern": "struct \\w+ \\{.*?\\}", "multiline": true, "output_mode": "count"], in: ws, rg: engine(e))
        #expect(count.text.hasSuffix("Total: 2 matches in 1 file."), "\(e): \(count.text)")
    }

    @Test(arguments: engines) func lookAroundAndBadPatterns(_ e: String) async throws {
        let ws = try makeProject()
        let look = await grep(["pattern": "(?<=func )greet", "glob": "*.swift"], in: ws, rg: engine(e))
        #expect(look.text == "src/main.swift:12: func greet() { print(\"Hello\") }", "\(e): \(look.text)")
        let bad = await grep(["pattern": "(unclosed"], in: ws, rg: engine(e))
        #expect(bad.isError && bad.text.contains("invalid regular expression"), "\(e): \(bad.text)")
    }

    @Test(arguments: engines) func binaryFilesAndCRLFLines(_ e: String) async throws {
        let ws = try makeProject()
        try Data("abc\0def greet\n".utf8).write(to: ws.root.appending(path: "blob.dat"))
        try put("greet windows\r\nnext\r\n", "win.txt", in: ws)
        let out = await grep(["pattern": "greet"], in: ws, rg: engine(e))
        #expect(!out.text.contains("blob.dat"), "\(e)")
        #expect(out.text.contains("win.txt:1: greet windows\n") || out.text.hasSuffix("win.txt:1: greet windows"), "\(e): \(out.text)")
    }

    @Test(arguments: engines) func withheldAndDeniedFilesNeverReachTheEngine(_ e: String) async throws {
        var ws = try makeProject(git: true)
        try put("API_KEY=sk-live-1\n", ".env", in: ws)
        try put("API_KEY=from-config\n", "config/app.txt", in: ws)
        ws.withheld = WithheldFiles(patterns: WithheldFiles.defaults, host: "api.example.com")
        let out = await grep(["pattern": "API_KEY", "output_mode": "count"], in: ws, rg: engine(e))
        #expect(!out.text.contains(".env"), "\(e): \(out.text)")
        #expect(out.text.contains("config/app.txt: 1"))
        #expect(out.text.contains("[1 file withheld from remote models weren't searched.]"))
    }

    @Test func bothEnginesAgreeOnTheProject() async throws {
        let ws = try makeProject(git: true)
        for args: [String: JSONValue] in [["pattern": "greet"], ["pattern": "GREET", "case_insensitive": true],
                                          ["pattern": "line \\d+", "output_mode": "count"], ["pattern": "^// line 1[0-9]$", "context": 2]] {
            let a = await grep(args, in: ws, rg: engine("rg")), b = await grep(args, in: ws, rg: nil)
            #expect(a.text == b.text, "\(args)")
        }
    }

    @Test func globListsNewestFirst() async throws {
        let ws = try makeProject()
        let fm = FileManager.default
        try fm.setAttributes([.modificationDate: Date(timeIntervalSinceNow: -3600)], ofItemAtPath: ws.root.appending(path: "src/main.swift").path)
        try fm.setAttributes([.modificationDate: Date(timeIntervalSinceNow: -60)], ofItemAtPath: ws.root.appending(path: "src/util/helpers.swift").path)
        let out = try await GlobTool().run(ToolArguments(["pattern": "*.swift"]), context: ToolContext(workspace: ws))
        #expect(out.text == "src/util/helpers.swift\nsrc/main.swift")
    }
}

@Suite struct Phase1ScenarioTests {
    @Test func warnCountChecksTheNumberNotTheTrap() throws {
        let dir = FileManager.default.temporaryDirectory.appending(path: "kk-warn-\(UUID().uuidString.prefix(8))")
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: dir) }
        let prompt = try Scenarios.warnCount.prepare(dir)
        #expect(prompt.contains("build.log"))
        let n = Fixtures.buildLogWarnings(dir)
        let text = try String(contentsOf: dir.appending(path: "build.log"), encoding: .utf8)
        let loose = text.components(separatedBy: "\n").filter { $0.contains("warning") }.count
        #expect(n > 300 && loose > n)
        func record(_ answer: String) -> RunRecord {
            var r = RunRecord()
            r.messages = [.user(prompt), ChatMessage(role: .assistant, content: answer)]
            return r
        }
        #expect(Scenarios.warnCount.check(dir, record("There are \(n) warnings.")).passed)
        #expect(!Scenarios.warnCount.check(dir, record("There are \(loose) warnings.")).passed)
        #expect(Scenarios.named(["phase1"]).map(\.id) == ["warn-count"])
        #expect(Scenarios.named(["warn-count"]).count == 1)
    }
}

/// A history where the model read `path` (a read_file call and its result), then the user asks `then`.
func historyHavingRead(_ path: String, then request: String) -> [ChatMessage] {
    let call = ToolCall(id: "seed_read", name: "read_file", arguments: #"{"path":"\#(path)"}"#)
    return [.user("look first"), ChatMessage(role: .assistant, content: "", toolCalls: [call]),
            ChatMessage(role: .tool, content: "(contents)", toolCallID: "seed_read",
                        toolResult: ToolResultInfo(toolName: "read_file", isError: false, truncated: false, duration: 0)),
            .user(request)]
}

// MARK: B5 edit tooling

private func tool(_ t: some Tool, _ args: [String: JSONValue], in ws: Workspace, reads: FileReads? = nil) async -> ToolOutput {
    var context = ToolContext(workspace: ws)
    context.reads = reads
    do { return try await t.run(ToolArguments(args), context: context) }
    catch let f as ToolFailure { return .error(f.message) }
    catch { return .error("\(error)") }
}

private func text(_ ws: Workspace, _ path: String) -> String {
    (try? String(contentsOf: ws.root.appending(path: path), encoding: .utf8)) ?? ""
}

@Suite struct EditB5Tests {
    @Test func severalEditsInOneCallAllOrNone() async throws {
        let ws = try makeProject()
        try put("a = 1\nb = 2\nc = 3\n", "v.py", in: ws)
        let ok = await tool(EditFileTool(), ["path": "v.py", "edits": [["old_string": "a = 1", "new_string": "a = 10"],
                                                                       ["old_string": "c = 3", "new_string": "c = 30"]]], in: ws)
        #expect(!ok.isError, "\(ok.text)")
        #expect(text(ws, "v.py") == "a = 10\nb = 2\nc = 30\n")
        #expect(ok.text.contains("2 replacements"))
        #expect(ok.text.contains("1\ta = 10") && ok.text.contains("3\tc = 30"))
        // The second edit fails: nothing is written.
        let bad = await tool(EditFileTool(), ["path": "v.py", "edits": [["old_string": "b = 2", "new_string": "b = 20"],
                                                                        ["old_string": "zzz", "new_string": "y"]]], in: ws)
        #expect(bad.isError && bad.text.contains("edit 2 of 2: ") && bad.text.contains("Nothing was changed."))
        #expect(text(ws, "v.py") == "a = 10\nb = 2\nc = 30\n")
        // Edits apply in order: the second sees the first's result. A JSON string of edits works too.
        let chained = await tool(EditFileTool(), ["file_path": "v.py",
                                                  "edits": #"[{"old_string":"b = 2","new_string":"b = 3"},{"old_string":"b = 3","new_string":"b = 4"}]"#], in: ws)
        #expect(!chained.isError, "\(chained.text)")
        #expect(text(ws, "v.py").contains("b = 4\n"))
        // The path inside the edits (Gemma 4 did this live), and affectedFiles agrees (it named the folder before).
        let inner = ToolArguments(["edits": [["path": "v.py", "old_string": "b = 4", "new_string": "b = 5"]], "replace_all": true])
        #expect(try EditFileTool().affectedFiles(inner, context: ToolContext(workspace: ws)).map(\.lastPathComponent) == ["v.py"])
        let placed = await tool(EditFileTool(), inner.values, in: ws)
        #expect(!placed.isError && text(ws, "v.py").contains("b = 5\n"), "\(placed.text)")
        let none = ToolArguments(["edits": [["old_string": "a", "new_string": "b"]]])
        #expect(throws: ToolFailure.self) { try EditFileTool().affectedFiles(none, context: ToolContext(workspace: ws)) }
        let twoFiles = await tool(EditFileTool(), ["edits": [["path": "v.py", "old_string": "a", "new_string": "b"],
                                                            ["path": "w.py", "old_string": "a", "new_string": "b"]]], in: ws)
        #expect(twoFiles.isError && twoFiles.text.contains("one file per call"))
        #expect(EditFileTool().summary(ToolArguments(["path": "v.py", "edits": [["old_string": "a", "new_string": "b"], ["old_string": "c", "new_string": "d"]]])) == "Edit v.py (2 changes)")
    }

    @Test func aLooseMatchIsUsedWhenItIsUnique() async throws {
        let ws = try makeProject()
        try put("def f():\n    if x:\n        return 1\n    return 2\n", "f.py", in: ws)
        // Indentation lost (the model wrote it flush left): matched, and the new text gets the file's indentation.
        let out = await tool(EditFileTool(), ["path": "f.py", "old_string": "if x:\n    return 1", "new_string": "if x:\n    return 10"], in: ws)
        #expect(!out.isError, "\(out.text)")
        #expect(text(ws, "f.py") == "def f():\n    if x:\n        return 10\n    return 2\n")
        #expect(out.text.contains("only after ignoring indentation and trailing whitespace") && out.text.contains("file's indentation"))
        // Trailing whitespace in the file.
        try put("x = 1   \ny = 2\n", "t.py", in: ws)
        let trail = await tool(EditFileTool(), ["path": "t.py", "old_string": "x = 1\ny = 2", "new_string": "x = 1\ny = 3"], in: ws)
        #expect(!trail.isError && text(ws, "t.py") == "x = 1\ny = 3\n", "\(trail.text)")
        #expect(trail.text.contains("ignoring trailing whitespace"))
        // Two loose places: refused, with where they are.
        try put("  a()\n  b\n    a()\n    b\n", "two.py", in: ws)
        let two = await tool(EditFileTool(), ["path": "two.py", "old_string": "a()\nb", "new_string": "c()\nb"], in: ws)
        #expect(two.isError && two.text.contains("matches 2 places (lines 1, 3)"), "\(two.text)")
        // CRLF files keep their line ends.
        try Data("if x:\r\n    go()\r\n".utf8).write(to: ws.root.appending(path: "w.py"))
        let crlf = await tool(EditFileTool(), ["path": "w.py", "old_string": "if x:\ngo()", "new_string": "if x:\nstop()"], in: ws)
        #expect(!crlf.isError, "\(crlf.text)")
        #expect(text(ws, "w.py") == "if x:\r\n    stop()\r\n")
    }

    @Test func editsNeedAReadAndAFreshOne() async throws {
        let ws = try makeProject()
        let reads = FileReads()
        let unread = await tool(EditFileTool(), ["path": "README.md", "old_string": "A demo", "new_string": "The demo"], in: ws, reads: reads)
        #expect(unread.isError && unread.text.contains("hasn't been read"))
        _ = await tool(ReadFileTool(), ["path": "README.md", "limit": 1], in: ws, reads: reads)     // a partial read counts
        let edited = await tool(EditFileTool(), ["path": "README.md", "old_string": "A demo", "new_string": "The demo"], in: ws, reads: reads)
        #expect(!edited.isError, "\(edited.text)")
        // Its own edit keeps the file fresh: a second edit needs no read.
        let again = await tool(EditFileTool(), ["path": "README.md", "old_string": "The demo", "new_string": "Our demo"], in: ws, reads: reads)
        #expect(!again.isError, "\(again.text)")
        // Changed by someone else: refused until read again.
        try await Task.sleep(for: .milliseconds(20))
        try put("# Demo\n\nChanged by the user.\n", "README.md", in: ws)
        let stale = await tool(EditFileTool(), ["path": "README.md", "old_string": "Changed", "new_string": "Edited"], in: ws, reads: reads)
        #expect(stale.isError && stale.text.contains("changed since you last read it"))
        // write_file: replacing an unread file is refused, creating or appending isn't.
        let over = await tool(WriteFileTool(), ["path": "docs/guide.md", "content": "new\n"], in: ws, reads: reads)
        #expect(over.isError && over.text.contains("hasn't been read"))
        #expect(!(await tool(WriteFileTool(), ["path": "docs/guide.md", "content": "more\n", "append": true], in: ws, reads: reads)).isError)
        #expect(!(await tool(WriteFileTool(), ["path": "docs/new.md", "content": "x\n"], in: ws, reads: reads)).isError)
    }

    @Test func theLogIsSeededFromTheHistory() async throws {
        let ws = try makeProject()
        let reads = FileReads.seeded(from: historyHavingRead("README.md", then: "go"), workspace: ws)
        #expect(reads.hasRead(ws.root.appending(path: "README.md")))
        #expect(!reads.hasRead(ws.root.appending(path: "docs/guide.md")))
        // A file changed after that read (its result's time) needs another.
        try await Task.sleep(for: .milliseconds(20))
        try put("# Demo\nnew\n", "README.md", in: ws)
        #expect(throws: ToolFailure.self) { try reads.check(ws.root.appending(path: "README.md"), path: "README.md") }
        // A failed read doesn't count.
        var h = historyHavingRead("docs/guide.md", then: "go")
        h[2].toolResult?.isError = true
        #expect(!FileReads.seeded(from: h, workspace: ws).hasRead(ws.root.appending(path: "docs/guide.md")))
    }

    @Test func theLoopRefusesAnUnreadEditAndTheModelRecovers() async throws {
        let ws = try makeProject()
        let (client, _) = MockServer.client(.init(turns: [
            SSE.toolCall("e1", "edit_file", #"{"path":"README.md","old_string":"A demo project.","new_string":"A fixed project."}"#),
            SSE.toolCall("r1", "read_file", #"{"path":"README.md"}"#),
            SSE.toolCall("e2", "edit_file", #"{"path":"README.md","old_string":"A demo project.","new_string":"A fixed project."}"#),
            SSE.content("done"),
        ]))
        let config = AgentConfig(tools: AllTools.all, policy: PermissionPolicy(mode: .fullAuto))
        let results = Results()
        await AgentLoop.run(client: client, model: "m", systemPrompt: "S", history: [.user("fix it")], config: config,
                            workspace: ws) { if case .toolFinished(let m) = $0 { results.add(m) } }
        #expect(results.all.map { $0.toolResult?.isError == true } == [true, false, false])
        #expect(text(ws, "README.md").contains("A fixed project."))
    }
}

private final class Results: @unchecked Sendable {
    private let lock = NSLock()
    private var items: [ChatMessage] = []
    func add(_ m: ChatMessage) { lock.withLock { items.append(m) } }
    var all: [ChatMessage] { lock.withLock { items } }
}

@Suite struct ApplyPatchB5Tests {
    @Test func v4aUpdatesAddsDeletesAndMoves() async throws {
        let ws = try makeProject()
        try put("def a():\n    return 1\n\n\ndef b():\n    return 2\n", "m.py", in: ws)
        try put("old\n", "gone.txt", in: ws)
        try put("keep\n", "src/move.txt", in: ws)
        let patch = """
            *** Begin Patch
            *** Update File: m.py
            @@ def b():
            -    return 2
            +    return 20
            *** Add File: docs/new.md
            +# New
            +text
            *** Delete File: gone.txt
            *** Update File: src/move.txt
            *** Move to: src/moved.txt
            @@
            -keep
            +kept
            *** End Patch
            """
        let reads = FileReads()
        for p in ["m.py", "src/move.txt"] { reads.record(ws.root.appending(path: p)) }
        let out = await tool(ApplyPatchTool(), ["patch": .string(patch)], in: ws, reads: reads)
        #expect(!out.isError, "\(out.text)")
        #expect(text(ws, "m.py") == "def a():\n    return 1\n\n\ndef b():\n    return 20\n")
        #expect(text(ws, "docs/new.md") == "# New\ntext\n")
        #expect(!FileManager.default.fileExists(atPath: ws.root.appending(path: "gone.txt").path))
        #expect(!FileManager.default.fileExists(atPath: ws.root.appending(path: "src/move.txt").path))
        #expect(text(ws, "src/moved.txt") == "kept\n")
        #expect(out.text.contains("Updated m.py (+1 −1).") && out.text.contains("Added docs/new.md (2 lines).") && out.text.contains("Deleted gone.txt."))
        #expect(out.display?.contains("+    return 20") == true)
    }

    @Test func unifiedDiffsAndLooseContext() async throws {
        let ws = try makeProject()
        try put("one\ntwo\nthree\nfour\n", "n.txt", in: ws)
        let diff = """
            --- a/n.txt
            +++ b/n.txt
            @@ -1,4 +1,4 @@
             one
            -two
            +2
             three
             four
            """
        let out = await tool(ApplyPatchTool(), ["patch": .string(diff)], in: ws)
        #expect(!out.isError, "\(out.text)")
        #expect(text(ws, "n.txt") == "one\n2\nthree\nfour\n")
        // Context with the wrong indentation still lands, with a note.
        try put("class A:\n    def f(self):\n        pass\n", "a.py", in: ws)
        let loose = "*** Begin Patch\n*** Update File: a.py\n def f(self):\n-    pass\n+    return 1\n*** End Patch"
        let lo = await tool(ApplyPatchTool(), ["patch": .string(loose)], in: ws)
        #expect(!lo.isError, "\(lo.text)")
        #expect(lo.text.contains("only after ignoring indentation"))
        #expect(text(ws, "a.py").contains("    return 1\n"))
    }

    @Test func aPatchThatDoesntApplyChangesNothing() async throws {
        let ws = try makeProject()
        try put("x\n", "ok.txt", in: ws)
        let patch = "*** Begin Patch\n*** Update File: ok.txt\n-x\n+y\n*** Update File: README.md\n-not in the file\n+z\n*** End Patch"
        let out = await tool(ApplyPatchTool(), ["patch": .string(patch)], in: ws)
        #expect(out.isError && out.text.contains("doesn't match the file") && out.text.contains("not in the file"))
        #expect(text(ws, "ok.txt") == "x\n")
        let unread = await tool(ApplyPatchTool(), ["patch": "*** Begin Patch\n*** Update File: ok.txt\n-x\n+y\n*** End Patch"], in: ws, reads: FileReads())
        #expect(unread.isError && unread.text.contains("hasn't been read"))
        let exists = await tool(ApplyPatchTool(), ["patch": "*** Begin Patch\n*** Add File: ok.txt\n+y\n*** End Patch"], in: ws)
        #expect(exists.isError && exists.text.contains("already exists"))
        let junk = await tool(ApplyPatchTool(), ["patch": "please change x to y"], in: ws)
        #expect(junk.isError && junk.text.contains("no file headers"))
        #expect(try ApplyPatchTool().affectedFiles(ToolArguments(["patch": "*** Begin Patch\n*** Update File: ok.txt\n*** Move to: b.txt\n*** End Patch"]),
                                                   context: ToolContext(workspace: ws)).map(\.lastPathComponent) == ["ok.txt", "b.txt"])
    }

    @Test func offeredToGPTFamiliesByProfile() {
        let ep = UUID()
        #expect(ModelProfile.defaults(endpointID: ep, model: "openai/gpt-oss-120b").offersPatchTool)
        #expect(ModelProfile.defaults(endpointID: ep, model: "gpt-5.1-codex").offersPatchTool)
        #expect(ModelProfile.defaults(endpointID: ep, model: "openai/o4-mini").offersPatchTool)
        #expect(!ModelProfile.defaults(endpointID: ep, model: "google/gemma-4-26b-a4b-qat").offersPatchTool)
        var p = ModelProfile.defaults(endpointID: ep, model: "qwen/qwen3-coder-30b")
        p.patchTool = true
        #expect(p.offersPatchTool)
        // gpt-oss keeps its own history shape (its row comes after GPT's).
        #expect(ModelProfile.defaults(endpointID: ep, model: "openai/gpt-oss-120b").history.sendReasoning)
    }
}

@Suite struct EditRulesB5Tests {
    @Test func editRulesSeeEveryPathACallNames() throws {
        let root = URL(fileURLWithPath: "/tmp/kk-rules-proj")
        let rules = PermissionRules(rules: [
            PermissionRule(action: .deny, tool: "Edit", specifier: "secrets/**", source: "test"),
            PermissionRule(action: .allow, tool: "Edit", specifier: "src/**", source: "test"),
        ], root: root)
        func decide(_ tool: String, _ args: [String: JSONValue]) -> PermissionRule.Action? { rules.decision(toolName: tool, args: ToolArguments(args))?.action }
        #expect(decide("edit_file", ["path": "secrets/key.txt", "old_string": "a", "new_string": "b"]) == .deny)
        #expect(decide("edit_file", ["file_path": "secrets/key.txt", "old_string": "a", "new_string": "b"]) == .deny)
        #expect(decide("edit_file", ["edits": [["path": "secrets/key.txt", "old_string": "a", "new_string": "b"]]]) == .deny)
        let patch = { (paths: [String]) -> JSONValue in
            .string("*** Begin Patch\n" + paths.map { "*** Update File: \($0)\n-a\n+b\n" }.joined() + "*** End Patch") }
        #expect(decide("apply_patch", ["patch": patch(["src/a.swift", "secrets/key.txt"])]) == .deny)   // any path for deny
        #expect(decide("apply_patch", ["patch": patch(["src/a.swift", "src/b.swift"])]) == .allow)
        #expect(decide("apply_patch", ["patch": patch(["src/a.swift", "README.md"])]) == nil)           // all paths for allow
    }
}
