# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

"""Property tests for ``is_subset`` / ``is_superset`` / ``is_disjoint``.

Each relation is pinned to its set-algebra definition (the oracle the methods
optimize): ``is_disjoint`` to ``(a & b).is_empty`` and ``is_subset`` to
``(a & ~b).is_empty``. The plain strategy exercises the bounds-only fast path;
the ``===`` strategy forces the algebra fallback, so the same oracle guards
both code paths. Pointwise-membership and symmetry are also checked.
"""

from __future__ import annotations

import pytest
from hypothesis import given
from hypothesis import strategies as st

from packaging._ranges import range_is_empty
from packaging.ranges import RangeRelation, VersionRange
from packaging.specifiers import SpecifierSet

from .strategies import (
    SETTINGS,
    VERSION_POOL,
    rich_specifier_sets,
    specifier_sets,
)

pytestmark = pytest.mark.property


def _union_all(spec_sets: list[SpecifierSet]) -> VersionRange:
    """The range accepting any version any of *spec_sets* accepts."""
    result = spec_sets[0].to_range()
    for spec_set in spec_sets[1:]:
        result = result | spec_set.to_range()
    return result


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_disjoint_matches_algebra_plain(a: SpecifierSet, b: SpecifierSet) -> None:
    ra, rb = a.to_range(), b.to_range()
    assert ra.is_disjoint(rb) == (ra & rb).is_empty


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_subset_matches_algebra_plain(a: SpecifierSet, b: SpecifierSet) -> None:
    ra, rb = a.to_range(), b.to_range()
    assert ra.is_subset(rb) == (ra & ~rb).is_empty


@given(
    a=st.lists(rich_specifier_sets(), min_size=2, max_size=4),
    b=st.lists(rich_specifier_sets(), min_size=2, max_size=4),
)
@SETTINGS
def test_relations_match_algebra_after_set_operations(
    a: list[SpecifierSet], b: list[SpecifierSet]
) -> None:
    """Union several ranges to exercise walks over multiple intervals."""
    ra, rb = _union_all(a), _union_all(b)
    # Every operation must preserve the walk's non-empty-interval invariant.
    operands = (ra, rb, ~ra, ra | rb, ra & rb, ra - rb)
    for operand in operands:
        assert all(not range_is_empty(*interval) for interval in operand._bounds)
        for other in operands:
            assert operand.is_disjoint(other) == (operand & other).is_empty
            relation = operand.relation(other)
            assert relation.is_disjoint == (operand & other).is_empty
            assert relation.is_subset == (operand & ~other).is_empty


@given(
    a=rich_specifier_sets(include_arbitrary=True),
    b=rich_specifier_sets(include_arbitrary=True),
)
@SETTINGS
def test_disjoint_matches_algebra_rich(a: SpecifierSet, b: SpecifierSet) -> None:
    """``===`` ranges defer to the algebra; ``_is_plain`` must gate them out."""
    ra, rb = a.to_range(), b.to_range()
    assert ra.is_disjoint(rb) == (ra & rb).is_empty


@given(
    a=rich_specifier_sets(include_arbitrary=True),
    b=rich_specifier_sets(include_arbitrary=True),
)
@SETTINGS
def test_subset_matches_algebra_rich(a: SpecifierSet, b: SpecifierSet) -> None:
    """``===`` ranges defer to the algebra; ``_is_plain`` must gate them out."""
    ra, rb = a.to_range(), b.to_range()
    assert ra.is_subset(rb) == (ra & ~rb).is_empty


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_superset_is_subset_mirror(a: SpecifierSet, b: SpecifierSet) -> None:
    ra, rb = a.to_range(), b.to_range()
    assert ra.is_superset(rb) == rb.is_subset(ra)


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_disjoint_symmetric(a: SpecifierSet, b: SpecifierSet) -> None:
    ra, rb = a.to_range(), b.to_range()
    assert ra.is_disjoint(rb) == rb.is_disjoint(ra)


@given(spec_set=specifier_sets())
@SETTINGS
def test_subset_and_superset_reflexive(spec_set: SpecifierSet) -> None:
    r = spec_set.to_range()
    assert r.is_subset(r)
    assert r.is_superset(r)


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_intersection_is_subset_and_pointwise(a: SpecifierSet, b: SpecifierSet) -> None:
    """``a & b`` is a subset of each operand, with consistent membership.

    Two independently drawn ranges are rarely a subset pair, so the
    intersection (always contained in each operand) drives the True branch
    in every example. Pointwise membership over the pool must agree.
    """
    ra, rb = a.to_range(), b.to_range()
    inter = ra & rb
    assert inter.is_subset(ra)
    assert inter.is_subset(rb)
    assert all(v in ra and v in rb for v in VERSION_POOL if v in inter)


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_disjoint_implies_no_shared_member(a: SpecifierSet, b: SpecifierSet) -> None:
    ra, rb = a.to_range(), b.to_range()
    if ra.is_disjoint(rb):
        assert not any(v in ra and v in rb for v in VERSION_POOL)


@given(spec_set=specifier_sets())
@SETTINGS
def test_empty_is_subset_and_disjoint(spec_set: SpecifierSet) -> None:
    r = spec_set.to_range()
    assert VersionRange.empty().is_subset(r)
    assert VersionRange.empty().is_disjoint(r)


@given(
    a=rich_specifier_sets(include_arbitrary=True),
    b=rich_specifier_sets(include_arbitrary=True),
    prereleases=st.sampled_from([None, True, False]),
)
@SETTINGS
def test_relation_matches_algebra(
    a: SpecifierSet, b: SpecifierSet, prereleases: bool | None
) -> None:
    ra = SpecifierSet(str(a), prereleases=prereleases).to_range()
    rb = SpecifierSet(str(b), prereleases=prereleases).to_range()
    relation = ra.relation(rb)
    assert relation.is_subset == (ra & ~rb).is_empty
    assert relation.is_disjoint == (ra & rb).is_empty
    assert (relation is RangeRelation.EMPTY) == ra.is_empty


@given(a=specifier_sets(), b=specifier_sets())
@SETTINGS
def test_relation_contains_intersection(a: SpecifierSet, b: SpecifierSet) -> None:
    ra, rb = a.to_range(), b.to_range()
    intersection = ra & rb
    contained = {RangeRelation.EMPTY, RangeRelation.SUBSET}
    assert intersection.relation(ra) in contained
    assert intersection.relation(rb) in contained
